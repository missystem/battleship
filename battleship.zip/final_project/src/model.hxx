#pragma once

#include <ge211.hxx>

class Model
{

};
