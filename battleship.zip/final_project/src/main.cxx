#include "controller.hxx"

int
main()
{
    Controller().run();

    return 0;
}
